/*
 * Este  proyecto es de código abierto. Para su utilización deberá conservar
 * los datos del autor y esta licencia.   
 */

package leagueprediction;

import java.util.ArrayList;

/**
 *
 * @author Andrés Enrique Sanabria Flores
 * andrs.dev@gmail.com
 * 
 * Universidad InterNaciones
 * Proyecto 1 - Análisis de algoritmos
 */


//Define la clase general de la Liga de equipos
public class League {
    public static String name;
    public static int lenght;
    public static ArrayList<Team> teamsList = new ArrayList<>();
    public static ArrayList<Player> playersList = new ArrayList<>();
    
    public League(String name){
        League.name = name;
        League.lenght = 0;
    }
    
    //Añade equipos a la liga
    public static void addTeam(int code,String name,int fuerza){
        teamsList.add(new Team(code,name,fuerza));
        lenght++;
    }   
}
