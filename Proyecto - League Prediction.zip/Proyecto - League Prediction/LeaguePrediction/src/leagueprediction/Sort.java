/*
 * Este  proyecto es de código abierto. Para su utilización deberá conservar
 * los datos del autor y esta licencia.   
 */

package leagueprediction;

import java.util.ArrayList;

/**
 *
 * @author Andrés Enrique Sanabria Flores
 * andrs.dev@gmail.com
 * 
 * Universidad InterNaciones
 * Proyecto 1 - Análisis de algoritmos
 */
public class Sort {
    
    //Orden de mayor a menor de acuerdo a los puntos, diferencia de goles y goles a favor
    public static void bublesortTeams(ArrayList<Team> v)
    {
        int pos, n = v.size() - 1;
        Team t;

        while (n > 0)
        {
            pos = 0;
            for (int i = 1; i <= n; i++){               
                if (v.get(pos).puntos > v.get(i).puntos)
                    pos = i;
                else if (v.get(pos).puntos == v.get(i).puntos){
                     if((v.get(pos).gf - v.get(pos).gc) > (v.get(i).gf - v.get(i).gc))
                        pos = i;
                     else if ((v.get(pos).gf - v.get(pos).gc) == (v.get(i).gf - v.get(i).gc))
                         if(v.get(pos).gf > v.get(i).gf)
                             pos = i;
                }
            }
                   

            t = v.get(pos);
            v.set(pos,v.get(n));
            v.set(n, t);
                   
            n--;
        }
    }
    
    //Ordena los jugadores de acuerdo a su cantidad de goles de mayor a menor.
    public static void bublesortPlayers(ArrayList<Player> v)
    {
        int pos, n = v.size() - 1;
        Player t;

        while (n > 0)
        {
            pos = 0;
            for (int i = 1; i <= n; i++)
                if (v.get(pos).goles > v.get(i).goles)
                    pos = i;

            t = v.get(pos);
            v.set(pos,v.get(n));
            v.set(n, t);
                   
            n--;
        }
    }
}
