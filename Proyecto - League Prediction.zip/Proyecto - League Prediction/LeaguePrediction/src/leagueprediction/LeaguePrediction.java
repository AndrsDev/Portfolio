/*
 * Este  proyecto es de código abierto. Para su utilización deberá conservar
 * los datos del autor y esta licencia.   
 */

package leagueprediction;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author Andrés Enrique Sanabria Flores
 * andrs.dev@gmail.com
 * 
 * Universidad InterNaciones
 * Proyecto 1 - Análisis de algoritmos
 */
public class LeaguePrediction {

    public static Scanner read = new Scanner(System.in);
    public static League league; 
    public static int matriz[][];
    public static int columnas;
    public static int[] pGoles;
   
      
    //Construye la liga, los equipos y jugadores a partir del archivo csv
    public static boolean buildLeague(String name){           
        League.name = name;
        
        String inputPath = System.getProperty("user.dir") + "\\files\\league.csv";
        String separator = ",";
        int cont = 0;
        
        BufferedReader br = null;
    
        //Lectura de archivo.csv y creación de la liga.
        try {      
            br = new BufferedReader(new FileReader(inputPath));
            String line = br.readLine();
            while ((line != null) && (!line.isEmpty()) ) {

                //Separación por campos
                String[] fields = line.split(separator);
                
                //Eliminación de los quotes <>
                for (int i = 0; i < fields.length; i++) {
                    fields[i] = fields[i].substring(1, fields[i].length() -1);             
                }
                
                //Agrega equipo a la liga
                League.addTeam(cont+1,fields[1], Integer.parseInt(fields[0]));
                
                //Agrega jugadores de cada equipo
                for (int i = 2; i < fields.length; i+=3) {
                    League.teamsList.get(cont).addPlayer(Integer.parseInt(fields[i]),fields[i+1],Integer.parseInt(fields[i+2]),fields[1]);
                }
               
                line = br.readLine();    
                cont++;
            }

            br.close();
            return true;
        } 
        catch (IOException | NumberFormatException e) {
            System.out.println("El archivo no se ha encontrado o su formato no es válido");
            return false;
        }
         
    }
    
    //Probabilidades de anotar goles según tabla proporcionada
    public static void llenadoProbabilidadGoles(){
        int i = 0;
        pGoles = new int[100];
        while(i<22){
            pGoles[i]=1;
            i++;
        }
        while(i<49){
            pGoles[i]=2;
            i++;
        }
        while(i<67){
            pGoles[i]=3;
            i++;
        }
        while(i<80){
            pGoles[i]=4;
            i++;
        }
        while(i<88){
            pGoles[i]=5;
            i++;
        }
        while(i<95){
            pGoles[i]=6;
            i++;
        }
        while(i<100){
            pGoles[i]=7;
            i++;
        }
    }
    
    //Elección del equipo ganador de acuerdo a las probabilidades en un partido.
    public static boolean Ganador(int pa, int pb){
        Random rnd = new Random();
        boolean pGanador[] = new boolean[100];
        int i = 0;
        
        while(i < pa){
            pGanador[i]= true;
            i++;
        }
        while((i < pa + pb) && (i < 100)){
            pGanador[i]= false;
            i++;
        }
        
        
        return pGanador[rnd.nextInt(100)];
    }
    
    //Llena una matriz para definir los enfrentamientos
    public static void llenadoDeMatriz(){
        if(League.lenght % 2 == 0){
            //[Rows][Columns]
            columnas = League.lenght / 2;
            matriz = new int[2][columnas];      
            
            
            //llenar matriz en caso de número de equipos par
            for (int i = 0; i < columnas; i++) {
                matriz[0][i] = i+1;
                matriz[1][i] = (League.lenght - i);           
            }              
            
        }else{
            columnas = (League.lenght + 1) / 2;
            matriz= new int[2][columnas];
            
            //llenar matriz en caso de número de equipos impar
            matriz[0][0]= 1;
            matriz[1][0]= 0;
            for (int i = 1; i < columnas; i++) {
                matriz[0][i] = i+1;
                matriz[1][i] = ((League.lenght + 1) - i);            
            }
        }     
    }
    
    /*Prepara la matriz para el siguiente round 
    (rota la matriz de acuerdo a Round Robin Tournament Algorithm)*/
    public static void rotacionMatriz(){
        
        int temp = matriz[0][columnas-1];
        for (int i = columnas - 1; i >= 2; i--) {
            matriz[0][i]=matriz[0][i-1];
        }
        matriz[0][1]= matriz[1][0];
               
        for (int i = 0; i <columnas - 1; i++) {
            matriz[1][i]=matriz[1][i+1];
        }
        
        matriz[1][columnas - 1] = temp;
                     
    }

    //Enfrenta dos equipos y de acuerdo a estadísticas calcula el resultado
    public static void enfrentar(int a, int b){
        Random rnd = new Random();
        
        //Comprueba que al equipo no le toque descanzar
        if((a != -1) && (b != -1 )){
            
            double fa = League.teamsList.get(a).fuerza;
            double fb = League.teamsList.get(b).fuerza;
            
            double totalFuerza = fa + fb;
            
            //Cálculo de probabilidades de cada equipo
            int probabilidadA = (int)Math.round(fa/totalFuerza * 100);
            int probabilidadB = (int)Math.round(fb/totalFuerza * 100);
            
            int g1 = pGoles[rnd.nextInt(100)];
            int g2 = pGoles[rnd.nextInt(100)]; 
            
            //Dependiendo de los goles se evalúa de acuerdo a la probabilidad de
            //cada equipo quien ganó.
            if (g1 == g2){
                League.teamsList.get(a).puntos += 1;     
                League.teamsList.get(a).gf += g1;
                League.teamsList.get(a).gc += g2;
                League.teamsList.get(a).addPlayersGoals(g1);    
                League.teamsList.get(a).partidosE++;
                
                League.teamsList.get(b).puntos += 1; 
                League.teamsList.get(b).gf += g2;
                League.teamsList.get(b).gc += g1;
                League.teamsList.get(b).addPlayersGoals(g2); 
                League.teamsList.get(b).partidosE++;
                
                
            }else if(Ganador(probabilidadA,probabilidadB)){
                League.teamsList.get(a).puntos += 3;
                League.teamsList.get(a).gf += Integer.max(g1, g2);
                League.teamsList.get(a).gc += Integer.min(g1, g2);  
                League.teamsList.get(a).addPlayersGoals(Integer.max(g1, g2));
                League.teamsList.get(a).partidosG++;
                
                League.teamsList.get(b).gf += Integer.min(g1, g2);
                League.teamsList.get(b).gc += Integer.max(g1, g2);  
                League.teamsList.get(b).addPlayersGoals(Integer.min(g1, g2)); 
                League.teamsList.get(b).partidosP++;
                               
            } else{
                League.teamsList.get(b).puntos += 3;
                League.teamsList.get(b).gf += Integer.max(g1, g2);
                League.teamsList.get(b).gc += Integer.min(g1, g2); 
                League.teamsList.get(b).addPlayersGoals(Integer.max(g1, g2)); 
                League.teamsList.get(b).partidosG++;
                
                League.teamsList.get(a).gf += Integer.min(g1, g2);
                League.teamsList.get(a).gc += Integer.max(g1, g2); 
                League.teamsList.get(a).addPlayersGoals(Integer.min(g1, g2)); 
                League.teamsList.get(a).partidosP++;
            }
           
            
        }
    }
    
    //Construcción de la predicción de la liga.
    public static void Simulation(){
        int rounds;
        
        llenadoDeMatriz();
        llenadoProbabilidadGoles();
        
        //Calculando la cantidad de rondas
        if(League.lenght % 2 ==0){
            rounds =  (League.lenght -1) *2;
        } else{
            rounds = League.lenght * 2;
        }
                 
        //Enfrentando a los equipos en cada ronda
        for (int i2 = 0; i2 < rounds; i2++) {
            for (int i = 0; i < columnas; i++) {
                enfrentar(matriz[0][i] - 1,matriz[1][i] - 1);
                if(League.teamsList.size() > 2)
                    rotacionMatriz();
            }              
        }   
    }
    
    //Mustra la salida de la tabla en consola
    public static void buildTable(){
        int nTeams = League.lenght;
        int nTeamsDescenso = (int)Math.round(nTeams * 0.15);
        
        Sort.bublesortTeams(League.teamsList);
        Sort.bublesortPlayers(League.playersList);
        
        //Tabla de posiciones de la liga
        String alignFormat1 = "| %-2d | %-24s | %-6d | %-2d | %-2d | %-2d | %-4d | %-4d | %-4d |%n";
        System.out.format("+----|--------------------------+--------+----+----+----+------+------+------+%n");
        System.out.format("| No | Equipos                  | Puntos | PG | PP | PE |  GF  |  GC  |  DG  |%n");
        System.out.format("+----|--------------------------+--------+----+----+----+------+------+------+%n");
             
      
        for (int i = 0; i < nTeams; i++) {

            System.out.format(alignFormat1,
                    i + 1,
                    League.teamsList.get(i).name, 
                    League.teamsList.get(i).puntos,
                    League.teamsList.get(i).partidosG,
                    League.teamsList.get(i).partidosP,
                    League.teamsList.get(i).partidosE,        
                    League.teamsList.get(i).gf,
                    League.teamsList.get(i).gc,
                    League.teamsList.get(i).gf - League.teamsList.get(i).gc                  
            );           
        }
        System.out.format("+----|--------------------------+--------+----+----+----+------+------+------+%n");
        
        //Tabla de equipos en descenso
        System.out.println();
        System.out.println("Los equipos en descenso son:");
        String alignFormat2 = "| %-2d | %-23s |%n";
        System.out.format("+----|-------------------------+%n");
        System.out.format("| No |         Equipos         |%n");
        System.out.format("+----|-------------------------+%n");
       
        for (int i = nTeams - nTeamsDescenso; i < nTeams; i++) {
            System.out.format(alignFormat2,
                    i+1,
                    League.teamsList.get(i).name
            );         
        }
        System.out.format("+----|-------------------------+%n");
        
        
        //Tabla de 3 máximos goleadores
        System.out.println();
        System.out.println("Los máximos goleadores son:");
        String alignFormat3 = "| %-2d | %-23s | %-5d |%n";
        System.out.format("+----|-------------------------+-------+%n");
        System.out.format("| No |         Nombres         | Goles |%n");
        System.out.format("+----|-------------------------+-------+%n");
       
        for (int i = 0; i < 3; i++) {
            System.out.format(alignFormat3,
                    i+1,
                    League.playersList.get(i).name,
                    League.playersList.get(i).goles
            );         
        }
        System.out.format("+----|-------------------------+-------+%n");
        
    }
    
    
    
    
    public static void main(String[] args) {       
        String leagueName;
        
        System.out.print("Ingrese el nombre de la liga: ");
        leagueName = read.nextLine();
        
        System.out.println();
        
        //Comprueba que la liga haya sido construida correctamente     
        if(buildLeague(leagueName)){
            Simulation();
       
            System.out.println();
            System.out.println("Simulación de la liga: " + leagueName);

            buildTable();   
        }         
    }
}
