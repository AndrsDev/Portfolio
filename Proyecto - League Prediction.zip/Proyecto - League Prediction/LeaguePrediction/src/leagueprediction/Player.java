/*
 * Este  proyecto es de código abierto. Para su utilización deberá conservar
 * los datos del autor y esta licencia.   
 */

package leagueprediction;

/**
 *
 * @author Andrés Enrique Sanabria Flores
 * andrs.dev@gmail.com
 * 
 * Universidad InterNaciones
 * Proyecto 1 - Análisis de algoritmos
 */
public class Player {
    int code;
    String name;
    int fuerza;
    int goles;
    String team;
    
    public Player(int code,String name, int fuerza, String team){
        this.code = code;
        this.name=name;
        this.fuerza = fuerza;
        this.goles = 0;
        this.team = team;
    }
    
    
}
