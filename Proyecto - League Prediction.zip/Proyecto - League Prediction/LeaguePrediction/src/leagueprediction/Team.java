/*
 * Este  proyecto es de código abierto. Para su utilización deberá conservar
 * los datos del autor y esta licencia.   
 */

package leagueprediction;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Andrés Enrique Sanabria Flores
 * andrs.dev@gmail.com
 * 
 * Universidad InterNaciones
 * Proyecto 1 - Análisis de algoritmos
 */

//Definición de la clase Team para ser utilizada por la clase League
public class Team {
    public int code;
    public String name;
    public int fuerza;
    public int numJugadores;
    public int puntos;
    public int partidosG;
    public int partidosP;
    public int partidosE; 
    public int gf;
    public int gc;
    
    private int probabilidadesJugadores[];  
    public ArrayList<Player> listPlayers = new ArrayList<>();
    
    public Team(int code,String name, int fuerza){
        this.code = code;
        this.name = name;
        this.fuerza = fuerza;
        this.numJugadores = 0;
        this.puntos =0;
        this.partidosG = 0;
        this.partidosP = 0;
        this.partidosE = 0;
        this.gf = 0;
        this.gc = 0;
        
    }
    
    //Agrega jugadores al equipo y al listado de la liga.
    public void addPlayer(int code, String name, int fuerza, String team){
        Player p = new Player(code, name, fuerza, team);
        
        this.listPlayers.add(p);
        League.playersList.add(p);
        
        numJugadores++;
    }
     
    //De acuerdo a las probabilidades obtiene un índice de jugador.
    private int indiceJugador(){
        Random rnd = new Random();
        int indices[] = new int[100];
        int n = listPlayers.size();
        int acum = 0;
        int i2 = 0;
        
        for (int i = 0; i < n; i++) {
            acum += probabilidadesJugadores[i];
            while((i2 < acum) && (i2 < 100)  ){
                indices[i2] = i;
                i2++;
            }               
        }
        
        return indices[rnd.nextInt(100)];
    }
    
    //Calcula las probabilidades de los jugadores y asigna los goles anotados 
    //de acuerdo a estas.
    public void addPlayersGoals(int goals){
        
        double fuerzaTotal = 0;
        int n = listPlayers.size();
            
        probabilidadesJugadores = new int[n];
       
        for (int i = 0; i < n; i++) {
            double fj = listPlayers.get(i).fuerza;
            fuerzaTotal+= fj;
        }
        
        for (int i = 0; i < n; i++) {
            double fj = listPlayers.get(i).fuerza;
            probabilidadesJugadores[i]= (int)Math.round(fj / fuerzaTotal * 100);
        }
        
        for (int i = 0; i < goals; i++) {
            int index = indiceJugador();
            listPlayers.get(index).goles+=1; 
        }     
    }
    
}
