﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

namespace Just_a_Game
{
    /// <summary>
    /// Clase estática con los valores que definen el juego.
    /// </summary>
    static class Game
    {
        public static string nombre = "Just a Game!";

        public static int cont;
        public static int cantJugadores;
        public static string[] nombres = new string[4];
        public static Color[] color = new Color[4];


        public static int[] posicionCasillasX = new int[57];
        public static int[] posicionCasillasY = new int[57];

        public static int turno()
        {
            return cont % cantJugadores;
        }

        /// <summary>
        /// Inicializa las condiciones del juego y establece las posiciones del tablero.
        /// </summary>
        public static void inicio()
        {

            cont = 0;
            color[0] = Color.Red;
            color[1] = Color.Blue;
            color[2] = Color.Orange;
            color[3] = Color.Green;


            posicionCasillasX[0] = 170;
            posicionCasillasY[0] = 95;

            posicionCasillasX[1] = 225;
            posicionCasillasY[1] = 105;

            posicionCasillasX[2] = 272;
            posicionCasillasY[2] = 107;

            posicionCasillasX[3] = 330;
            posicionCasillasY[3] = 107;

            posicionCasillasX[4] = 354;
            posicionCasillasY[4] = 60;

            posicionCasillasX[5] = 394;
            posicionCasillasY[5] = 47;

            posicionCasillasX[6] = 444;
            posicionCasillasY[6] = 49;
            
            posicionCasillasX[7] = 486;
            posicionCasillasY[7] = 76;
            
            posicionCasillasX[8] = 489;
            posicionCasillasY[8] = 127;
            
            posicionCasillasX[9] = 533;
            posicionCasillasY[9] = 125;
            
            posicionCasillasX[10] = 580;
            posicionCasillasY[10] = 101;
            
            posicionCasillasX[11] = 624;
            posicionCasillasY[11] = 79;
            
            posicionCasillasX[12] = 673;
            posicionCasillasY[12] = 57;
            
            posicionCasillasX[13] = 723;
            posicionCasillasY[13] = 74;
            
            posicionCasillasX[14] = 751;
            posicionCasillasY[14] = 115;
            
            posicionCasillasX[15] = 708;
            posicionCasillasY[15] = 142;
            
            posicionCasillasX[16] = 679;
            posicionCasillasY[16] = 178;
            
            posicionCasillasX[17] = 691;
            posicionCasillasY[17] = 227;
            
            posicionCasillasX[18] = 740;
            posicionCasillasY[18] = 233;
            
            posicionCasillasX[19] = 775;
            posicionCasillasY[19] = 259;
            
            posicionCasillasX[20] = 766;
            posicionCasillasY[20] = 310;
            
            posicionCasillasX[21] = 735;
            posicionCasillasY[21] = 347;
            
            posicionCasillasX[22] = 684;
            posicionCasillasY[22] = 345;
            
            posicionCasillasX[23] = 631;
            posicionCasillasY[23] = 336;
            
            posicionCasillasX[24] = 625;
            posicionCasillasY[24] = 285;
            
            posicionCasillasX[25] = 626;
            posicionCasillasY[25] = 235;
            
            posicionCasillasX[26] = 586;
            posicionCasillasY[26] = 212;
            
            posicionCasillasX[27] = 534;
            posicionCasillasY[27] = 206;
            
            posicionCasillasX[28] = 500;
            posicionCasillasY[28] = 233;
            
            posicionCasillasX[29] = 493;
            posicionCasillasY[29] = 283;
            
            posicionCasillasX[30] = 447;
            posicionCasillasY[30] = 306;
            
            posicionCasillasX[31] = 411;
            posicionCasillasY[31] = 278;
            
            posicionCasillasX[32] = 394;
            posicionCasillasY[32] = 233;
            
            posicionCasillasX[33] = 355;
            posicionCasillasY[33] = 203;
            
            posicionCasillasX[34] = 306;
            posicionCasillasY[34] = 204;
            
            posicionCasillasX[35] = 265;
            posicionCasillasY[35] = 228;
            
            posicionCasillasX[36] = 269;
            posicionCasillasY[36] = 277;
            
            posicionCasillasX[37] = 242;
            posicionCasillasY[37] = 312;
            
            posicionCasillasX[38] = 189;
            posicionCasillasY[38] = 299;
            
            posicionCasillasX[39] = 146;
            posicionCasillasY[39] = 322;
            
            posicionCasillasX[40] = 142;
            posicionCasillasY[40] = 372;
            
            posicionCasillasX[41] = 145;
            posicionCasillasY[41] = 423;
            
            posicionCasillasX[42] = 160;
            posicionCasillasY[42] = 473;
            
            posicionCasillasX[43] = 210;
            posicionCasillasY[43] = 466;
            
            posicionCasillasX[44] = 253;
            posicionCasillasY[44] = 435;
            
            posicionCasillasX[45] = 297;
            posicionCasillasY[45] = 402;
            
            posicionCasillasX[46] = 345;
            posicionCasillasY[46] = 387;
            
            posicionCasillasX[47] = 383;
            posicionCasillasY[47] = 417;
            
            posicionCasillasX[48] = 416;
            posicionCasillasY[48] = 457;
            
            posicionCasillasX[49] = 459;
            posicionCasillasY[49] = 479;
            
            posicionCasillasX[50] = 497;
            posicionCasillasY[50] = 444;
            
            posicionCasillasX[51] = 524;
            posicionCasillasY[51] = 399;
            
            posicionCasillasX[52] = 567;
            posicionCasillasY[52] = 402;
            
            posicionCasillasX[53] = 585;
            posicionCasillasY[53] = 452;
            
            posicionCasillasX[54] = 608;
            posicionCasillasY[54] = 495;
            
            posicionCasillasX[55] = 651;
            posicionCasillasY[55] = 509;
            
            posicionCasillasX[56] = 716;
            posicionCasillasY[56] = 509;


        }

        public static void fin()
        {
            MessageBox.Show("Game will restart.");
            Application.Restart();
        }


    }
}
