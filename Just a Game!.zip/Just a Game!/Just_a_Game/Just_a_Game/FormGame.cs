﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

/*
Nombre: Just a Game!
Función: Simular un juego de mesa por turnos.
Programador:    Nombre:  Andrés Enrique Sanabria Flores
                Institución educativa: Universidad InterNaciones
                correo: andressanabriaguitar1@gmail.com
                teléfono: 5987-3104
Recursos: Herencia
Creación: 09/10/2017
Última modificación: 16/10/2017
                     Por: Andrés Enrique Sanabria Flores
 */

namespace Just_a_Game
{
    //Forma principal del juego
    public partial class FormGame : Form
    {
        public FormGame()
        {
            InitializeComponent();
        }

        Dado dado;
        Player[] jugadores = new Player[4];
        public string nameP1;
        public string nameP2;
        public string nameP3;
        public string nameP4;

        /// <summary>
        /// Prepara el contenido de la forma para jugar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormGame_Load(object sender, EventArgs e)
        {

            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            Game.inicio();


            //Indicador de turno y jugadores
            tbTurn.Text = Game.nombres[Game.turno()];
            infoPanel.Text += " - " + Game.cantJugadores.ToString();

            // Instatncia del dado:
            dado = new Dado();
            dado.Name = "dado";
            dado.Width = 90;
            dado.Height = 90;
            dado.Left = 120;
            dado.Top = Height - dado.Height - 150;
            dado.SizeMode = PictureBoxSizeMode.StretchImage;
            dado.ImageLocation = Application.StartupPath + "/resources/cara5.png";
            this.Controls.Add(dado);
            dado.BringToFront();
            // ------------------------------------

            //Instancia de Jugadores
            Random rnd = new Random();
            for (int i = 0; i < Game.cantJugadores; i++)
            {
                jugadores[i] = new Player();
                jugadores[i].nombre = Game.nombres[i];
                jugadores[i].casilla = 0;
                jugadores[i].Width = 30;
                jugadores[i].Height = 30;
                jugadores[i].Left = Game.posicionCasillasX[0] - rnd.Next(10, 30);
                jugadores[i].Top = Game.posicionCasillasY[0] - rnd.Next(10, 30);
                jugadores[i].SizeMode = PictureBoxSizeMode.StretchImage;
                jugadores[i].color = Game.color[i];
                Bitmap myBitmap = new Bitmap(Application.StartupPath + "/resources/p" + (i + 1).ToString() + ".png");
                jugadores[i].Image = myBitmap;
                jugadores[i].BackColor = Color.Transparent;
                table.Controls.Add(jugadores[i]);


            }
            table.SendToBack();
            //-------------------------------------

            //Acomodar objetos en pantalla
            groupBox1.Height = 600;
            groupBox1.Width = 900;


            lbPlayer1.Text = Game.nombres[0];
            lbPlayer2.Text = Game.nombres[1];
            lbPlayer3.Text = Game.nombres[2];
            lbPlayer4.Text = Game.nombres[3];

            //----------------------------



        }

        /// <summary>
        /// Proceso que ejecuta la lógica del juego y actualiza la capa de vista
        /// </summary>
        private void procesoDeJuego()
        {
            
            
            int resultado = 0;
            //Se crea un hilo nuevo para visualizar las animaciones
            Control.CheckForIllegalCrossThreadCalls = false;
            Thread Hilo = new Thread(new ThreadStart(animacion));
            Hilo.Start();

            void animacion()
            {
                btnDado.Enabled = false;
                resultado = dado.lanzar();

                jugadores[Game.turno()].BringToFront();

                //El jugador avanza la cantidad de casillas que devuelve el dado.
                if (jugadores[Game.turno()].casilla + resultado <= 56)
                {
                    for (int i = 1; i <= resultado; i++)
                    {
                        jugadores[Game.turno()].casilla++;
                        jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                        jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;
                        Thread.Sleep(200);
                    }
                }
                else
                {
                    while (jugadores[Game.turno()].casilla < 56)
                    {
                        jugadores[Game.turno()].casilla++;
                        jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                        jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;
                        Thread.Sleep(200);
                    }
                }



                casillasEspeciales(jugadores[Game.turno()].casilla);

                Game.cont++;
                tbTurn.Text = Game.nombres[Game.turno()];
                tbTurn.BackColor = jugadores[Game.turno()].color;


                btnDado.Enabled = true;
            }
            
        }

        /// <summary>
        /// Ejecuta las acciones de las casillas especiales
        /// </summary>
        /// <param name="n"></param>
        private void casillasEspeciales(int n)
        {
  
            if(n == 5 || n == 33)
            {
                if (Game.cantJugadores > 1)
                {
                    MessageBox.Show("Switch place with a random player!");
                    Random rnd = new Random();
                    int selected, t;

                    do
                    {
                        selected = rnd.Next(Game.cantJugadores);
                    } while (selected == Game.turno());

                    t = jugadores[Game.turno()].casilla;
                    jugadores[Game.turno()].casilla = jugadores[selected].casilla;
                    jugadores[selected].casilla = t;

                    jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                    jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;

                    jugadores[selected].Left = Game.posicionCasillasX[jugadores[selected].casilla] - jugadores[selected].Width / 2;
                    jugadores[selected].Top = Game.posicionCasillasY[jugadores[selected].casilla] - jugadores[selected].Height / 2;

                }
                else
                {
                    MessageBox.Show("This box is disabled in mode of 1 player.");
                }
            }
            else if(n == 11)
            {
                MessageBox.Show("Walk 2 more boxes! :D");
                for (int i = 0; i < 2; i++)
                {
                    jugadores[Game.turno()].casilla++;
                    jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                    jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;
                    Thread.Sleep(200);
                }
            }         
            else if(n == 22)
            {
                MessageBox.Show("Go back 6 boxes! D:");
                for (int i = 0; i < 6; i++)
                {
                    jugadores[Game.turno()].casilla--;
                    jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                    jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;
                    Thread.Sleep(200);
                }
            }
            else if (n == 36)
            {
                MessageBox.Show("Roll the dice twice!");
                Game.cont--;
            }
            else if (n == 40)
            {
                MessageBox.Show("Walk 5 more boxes! :D");
                for (int i = 0; i < 5; i++)
                {
                    jugadores[Game.turno()].casilla++;
                    jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                    jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;
                    Thread.Sleep(200);
                }
            }
            else if (n == 44)
            {
                MessageBox.Show("Go back 4 boxes! D:");
                for (int i = 0; i < 4; i++)
                {
                    jugadores[Game.turno()].casilla--;
                    jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                    jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;
                    Thread.Sleep(200);
                }
            }
            else if (n == 49)
            {
                MessageBox.Show("Go back to the start! X_x");
                jugadores[Game.turno()].casilla = 0;
                jugadores[Game.turno()].Left = Game.posicionCasillasX[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Width / 2;
                jugadores[Game.turno()].Top = Game.posicionCasillasY[jugadores[Game.turno()].casilla] - jugadores[Game.turno()].Height / 2;

            }

            else if (n == 56)
            {
                MessageBox.Show("Congratulations, you win!");
                Game.fin();
            }




        }

       


        private void FormGame_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        private void btnDado_Click(object sender, EventArgs e)
        {
            procesoDeJuego();            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void instructionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormInstructions instructions = new FormInstructions();
            instructions.Show();
        }
    }
}
