﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Just_a_Game
{
    /// <summary>
    /// Clase que define el dado del juego. Hereda del tipo PictureBox
    /// </summary>
    public class Dado: PictureBox
    {
        string[] caras = new string[6];

        public int lanzar()
        {
            playSound(Application.StartupPath + "/resources/diceSound.wav");

            Random rnd = new Random();
            int factor = rnd.Next(15, 37);
            int i;
            for (i = 0; i <= factor; i++)
            {
                ImageLocation = Application.StartupPath + "/resources/cara" + (i % 6 + 1).ToString() + ".png";
                Thread.Sleep(10*i);
            }

            if (i % 6 == 0)
                return 6;
            else
                return i%6;
        }

        private void playSound(string path)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer();
            player.SoundLocation = path;
            player.Load();
            player.Play();
        }


    }
}
