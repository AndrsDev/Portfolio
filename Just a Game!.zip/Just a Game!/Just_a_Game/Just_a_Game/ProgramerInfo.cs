﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
Nombre: Just a Game!
Función: Simular un juego de mesa por turnos.
Programador:    Nombre:  Andrés Enrique Sanabria Flores
                Institución educativa: Universidad InterNaciones
                correo: andressanabriaguitar1@gmail.com
                teléfono: 5987-3104
Recursos: Herencia
Creación: 09/10/2017
Última modificación: 16/10/2017
                     Por: Andrés Enrique Sanabria Flores
 */

namespace Just_a_Game
{
    //Forma con la información del programador.
    public partial class ProgramerInfo : Form
    {
        public ProgramerInfo()
        {
            InitializeComponent();
        } 

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://uni.edu.gt/");
            }
            catch { }
        }
    }
}
