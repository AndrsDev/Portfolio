﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
/*
Nombre: Just a Game!
Función: Simular un juego de mesa por turnos.
Programador:    Nombre:  Andrés Enrique Sanabria Flores
                Institución educativa: Universidad InterNaciones
                correo: andressanabriaguitar1@gmail.com
                teléfono: 5987-3104
Recursos: Herencia
Creación: 09/10/2017
Última modificación: 16/10/2017
                     Por: Andrés Enrique Sanabria Flores
 */
namespace Just_a_Game
{
    //Forma para el inicio del juego
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        private void numPlayers_ValueChanged(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(numPlayers.Value);

            switch (num)
            {
                case 1:
                    tbPlayer1.Visible = true;
                    tbPlayer2.Visible = false;
                    tbPlayer3.Visible = false;
                    tbPlayer4.Visible = false;
                    break;
                case 2:
                    tbPlayer1.Visible = true;
                    tbPlayer2.Visible = true;
                    tbPlayer3.Visible = false;
                    tbPlayer4.Visible = false;
                    break;
                case 3:
                    tbPlayer1.Visible = true;
                    tbPlayer2.Visible = true;
                    tbPlayer3.Visible = true;
                    tbPlayer4.Visible = false;
                    break;
                case 4:
                    tbPlayer1.Visible = true;
                    tbPlayer2.Visible = true;
                    tbPlayer3.Visible = true;
                    tbPlayer4.Visible = true;
                    break;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int num = Convert.ToInt32(numPlayers.Value);

            switch (num)
            {
                case 1:
                    if (tbPlayer1.Text == "")
                        MessageBox.Show("Enter player name.");
                    else
                        abrirJuego();
                    break;
                case 2:
                    if (tbPlayer1.Text == "" || tbPlayer2.Text == "")
                        MessageBox.Show("Enter both players name.");
                    else
                        abrirJuego();
                    break;
                case 3:
                    if (tbPlayer1.Text == "" || tbPlayer2.Text == "" || tbPlayer3.Text == "")
                        MessageBox.Show("Enter three players name.");
                    else
                        abrirJuego();
                    break;
                case 4:
                    if (tbPlayer1.Text == "" || tbPlayer2.Text == "" || tbPlayer3.Text == "" || tbPlayer4.Text == "")
                        MessageBox.Show("Enter four players name.");
                    else
                        abrirJuego();
                    break;

            }


            void abrirJuego()
            {
                Game.cantJugadores = Convert.ToInt32(numPlayers.Value);
                Game.inicio();
                FormGame formGame = new FormGame();
                Game.nombres[0] = tbPlayer1.Text;
                Game.nombres[1] = tbPlayer2.Text;
                Game.nombres[2] = tbPlayer3.Text;
                Game.nombres[3] = tbPlayer4.Text;

                formGame.Show();

                this.Visible = false;
            }


        }

        private void DeveloperInfo_Click(object sender, EventArgs e)
        {
            ProgramerInfo info = new ProgramerInfo();
            info.Show();
        }
    }
}
