﻿namespace Just_a_Game
{
    partial class FormGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGame));
            this.table = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDado = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTurn = new System.Windows.Forms.TextBox();
            this.infoPanel = new System.Windows.Forms.GroupBox();
            this.lbPlayer4 = new System.Windows.Forms.Label();
            this.lbPlayer3 = new System.Windows.Forms.Label();
            this.lbPlayer2 = new System.Windows.Forms.Label();
            this.lbPlayer1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.instructionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.table)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.infoPanel.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // table
            // 
            this.table.BackColor = System.Drawing.Color.Transparent;
            this.table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.table.Image = ((System.Drawing.Image)(resources.GetObject("table.Image")));
            this.table.Location = new System.Drawing.Point(4, 27);
            this.table.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.table.Name = "table";
            this.table.Size = new System.Drawing.Size(892, 568);
            this.table.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.table.TabIndex = 0;
            this.table.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.table);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(351, 61);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(900, 600);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // btnDado
            // 
            this.btnDado.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDado.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDado.Location = new System.Drawing.Point(87, 600);
            this.btnDado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDado.Name = "btnDado";
            this.btnDado.Size = new System.Drawing.Size(159, 61);
            this.btnDado.TabIndex = 2;
            this.btnDado.Text = "Roll dice!";
            this.btnDado.UseVisualStyleBackColor = false;
            this.btnDado.Click += new System.EventHandler(this.btnDado_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Turn:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tbTurn
            // 
            this.tbTurn.BackColor = System.Drawing.Color.Red;
            this.tbTurn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tbTurn.ForeColor = System.Drawing.SystemColors.Window;
            this.tbTurn.Location = new System.Drawing.Point(87, 73);
            this.tbTurn.Name = "tbTurn";
            this.tbTurn.Size = new System.Drawing.Size(240, 29);
            this.tbTurn.TabIndex = 4;
            // 
            // infoPanel
            // 
            this.infoPanel.Controls.Add(this.lbPlayer4);
            this.infoPanel.Controls.Add(this.lbPlayer3);
            this.infoPanel.Controls.Add(this.lbPlayer2);
            this.infoPanel.Controls.Add(this.lbPlayer1);
            this.infoPanel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoPanel.Location = new System.Drawing.Point(37, 176);
            this.infoPanel.Name = "infoPanel";
            this.infoPanel.Size = new System.Drawing.Size(290, 257);
            this.infoPanel.TabIndex = 5;
            this.infoPanel.TabStop = false;
            this.infoPanel.Text = "Players";
            // 
            // lbPlayer4
            // 
            this.lbPlayer4.ForeColor = System.Drawing.Color.Green;
            this.lbPlayer4.Location = new System.Drawing.Point(6, 176);
            this.lbPlayer4.Name = "lbPlayer4";
            this.lbPlayer4.Size = new System.Drawing.Size(267, 23);
            this.lbPlayer4.TabIndex = 3;
            this.lbPlayer4.Text = "p4";
            this.lbPlayer4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPlayer3
            // 
            this.lbPlayer3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbPlayer3.Location = new System.Drawing.Point(6, 132);
            this.lbPlayer3.Name = "lbPlayer3";
            this.lbPlayer3.Size = new System.Drawing.Size(267, 23);
            this.lbPlayer3.TabIndex = 2;
            this.lbPlayer3.Text = "p3";
            this.lbPlayer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPlayer2
            // 
            this.lbPlayer2.ForeColor = System.Drawing.Color.Blue;
            this.lbPlayer2.Location = new System.Drawing.Point(6, 89);
            this.lbPlayer2.Name = "lbPlayer2";
            this.lbPlayer2.Size = new System.Drawing.Size(267, 23);
            this.lbPlayer2.TabIndex = 1;
            this.lbPlayer2.Text = "p2";
            this.lbPlayer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPlayer1
            // 
            this.lbPlayer1.ForeColor = System.Drawing.Color.Red;
            this.lbPlayer1.Location = new System.Drawing.Point(6, 47);
            this.lbPlayer1.Name = "lbPlayer1";
            this.lbPlayer1.Size = new System.Drawing.Size(267, 23);
            this.lbPlayer1.TabIndex = 0;
            this.lbPlayer1.Text = "p1";
            this.lbPlayer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.instructionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1280, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // instructionsToolStripMenuItem
            // 
            this.instructionsToolStripMenuItem.Name = "instructionsToolStripMenuItem";
            this.instructionsToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.instructionsToolStripMenuItem.Text = "Instructions";
            this.instructionsToolStripMenuItem.Click += new System.EventHandler(this.instructionsToolStripMenuItem_Click);
            // 
            // FormGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1280, 696);
            this.Controls.Add(this.infoPanel);
            this.Controls.Add(this.tbTurn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDado);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "FormGame";
            this.Text = "Just a Game!";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormGame_FormClosed);
            this.Load += new System.EventHandler(this.FormGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.table)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.infoPanel.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox table;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbTurn;
        private System.Windows.Forms.GroupBox infoPanel;
        private System.Windows.Forms.Label lbPlayer4;
        private System.Windows.Forms.Label lbPlayer3;
        private System.Windows.Forms.Label lbPlayer2;
        private System.Windows.Forms.Label lbPlayer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem instructionsToolStripMenuItem;
    }
}