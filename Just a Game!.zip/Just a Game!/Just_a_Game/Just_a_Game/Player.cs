﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Just_a_Game
{
    //Clase que hereda del tipo PictrueBox para instanciar jugadores.
    public class Player : PictureBox
    {
        public int casilla;
        public string nombre;
        public Color color;
    }
}
