﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
Nombre: Just a Game!
Función: Simular un juego de mesa por turnos.
Programador:    Nombre:  Andrés Enrique Sanabria Flores
                Institución educativa: Universidad InterNaciones
                correo: andressanabriaguitar1@gmail.com
                teléfono: 5987-3104
Recursos: Herencia
Creación: 09/10/2017
Última modificación: 16/10/2017
                     Por: Andrés Enrique Sanabria Flores
 */

namespace Just_a_Game
{
    //Forma de instrucciones del juego.
    public partial class FormInstructions : Form
    {
        public FormInstructions()
        {
            InitializeComponent();
        }
    }
}
