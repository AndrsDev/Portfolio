﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Totito
{
    class Player
    {
        public string nombre, signo;
        public int puntuación;

        public Player(string signo)
        {
            this.signo = signo;
            puntuación = 0;
        }       
    }
}
