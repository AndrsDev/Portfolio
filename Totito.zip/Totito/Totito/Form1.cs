﻿/*
Nombre: Totito
Función: Simular un juego típico de totito para dos jugadores y un jugador.
Programador:    Nombre:  Andrés Enrique Sanabria Flores
                Institución educativa: Universidad InterNaciones
                correo: andressanabriaguitar1@gmail.com
                teléfono: 5987-3104
Creación: 29/08/2017
Última modificación: 29/08/2017
                     Por: Andrés Enrique Sanabria Flores
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;


namespace Totito
{
    public partial class Form1 : Form
    {
        Game juego;
       
        public Form1()
        {
            InitializeComponent();
            juego = new Game();           
        }


        /// <summary>
        ///  Procedimiento que acomoda los objetos al empezar el juego
        /// </summary>
        public void acomodarJuego()
        {
            tbNombreJ1.ReadOnly = true;
            tbNombreJ2.ReadOnly = true;
            tablero.Enabled = true;
            empezarJuego.Enabled = false;

            instrucciones.Text = "¡Que gane el mejor!";
            label2.Left = 137;
            label2.Text = "Jugadores:";

            label3.Visible = false;

            tbNombreJ2.Top = 101;
            tbNombreJ2.Left = 141;
            tbNombreJ2.Width = 153;
            tbNombreJ1.Left = 141;
            tbNombreJ1.Width = 153;

            simbolo.Top = 134;
            simbolo.Left = 139;
            simbolo.Visible = true;

            scoreJ1.Visible = true;
            scoreJ2.Visible = true;
            label4.Visible = true;
            jugarIA.Enabled = false;
            tbJugadorIA.Enabled = false;
            gbDificultad.Enabled = false;
            btnObservarM.Enabled = false;

            moverFlecha();
        }

        /// <summary>
        /// Procedimiento que mueve la flecha para indicar el turno del jugador en modo de 2 jugadores. 
        /// </summary>
        public void moverFlecha()
        {
            lbIndicador.Visible = true;
            lbIndicador.Left = 40;
            flecha.Visible = true;
            flecha.Left = 95;

            if (juego.turno)
            {
                lbIndicador.Top = tbNombreJ1.Top;
                flecha.Top = tbNombreJ1.Top;
                simbolo.Text = juego.jugador1.signo;
            }
            else
            {
                lbIndicador.Top = tbNombreJ2.Top;
                flecha.Top = tbNombreJ2.Top;
                simbolo.Text = juego.jugador2.signo;
            }
        }

        /// <summary>
        /// Proceso que inicia la jugada de la máquina y que ingresa la jugada al tablero. 
        /// </summary>
        public void jugadaDeIA()
        {

            string coordenada;
            if (juego.tipo == 1)
                if (rbFacil.Checked)
                    coordenada = juego.inteligenciaNivel1();
                else if (rbIntermedio.Checked)
                    coordenada = juego.inteligenciaNivel2();
                else
                    coordenada = juego.inteligenciaNivel3();
            else
                coordenada = juego.inteligenciaNivel2();

            switch (coordenada)
            {
                case "00":
                    juego.ingresarJugada(ref btn00, 0, 0);
                    break;
                case "01":
                    juego.ingresarJugada(ref btn01, 0, 1);
                    break;
                case "02":
                    juego.ingresarJugada(ref btn02, 0, 2);
                    break;
                case "10":
                    juego.ingresarJugada(ref btn10, 1, 0);
                    break;
                case "11":
                    juego.ingresarJugada(ref btn11, 1, 1);
                    break;
                case "12":
                    juego.ingresarJugada(ref btn12, 1, 2);
                    break;
                case "20":
                    juego.ingresarJugada(ref btn20, 2, 0);
                    break;
                case "21":
                    juego.ingresarJugada(ref btn21, 2, 1);
                    break;
                case "22":
                    juego.ingresarJugada(ref btn22, 2, 2);
                    break;

            }


        }

        /// <summary>
        /// Proceso para vaciar todos los elementos del tablero
        /// </summary>
        public void reiniciarTablero()
        {
            tablero.Enabled = true;
            btn00.Enabled = true;
            btn01.Enabled = true;
            btn02.Enabled = true;
            btn10.Enabled = true;
            btn11.Enabled = true;
            btn12.Enabled = true;
            btn20.Enabled = true;
            btn21.Enabled = true;
            btn22.Enabled = true;

            btn00.Text = string.Empty;
            btn01.Text = string.Empty;
            btn02.Text = string.Empty;
            btn10.Text = string.Empty;
            btn11.Text = string.Empty;
            btn12.Text = string.Empty;
            btn20.Text = string.Empty;
            btn21.Text = string.Empty;
            btn22.Text = string.Empty;
        }

        /// <summary>
        /// Proceso que determina la navegación en la aplicación para 1 jugador.
        /// </summary>
        public void flujoDeJuego1Jugador()
        {
            if (!juego.fin)
                if (tbJugadorIA.Text != string.Empty)
                {
                    juego.jugador1.nombre = tbJugadorIA.Text;
                    juego.jugador2.nombre = "Inteligencia Artificial";
                    juego.tipo = 1;

                    tbJugadorIA.Enabled = false;
                    jugarIA.Enabled = false;
                    gbDificultad.Enabled = false;
                    tablero.Enabled = true;

                    empezarJuego.Enabled = false;
                    tbNombreJ1.Enabled = false;
                    tbNombreJ2.Enabled = false;
                    btnObservarM.Enabled = false;

                }
                else
                {
                    MessageBox.Show("Ingrese el nombre del jugador primero.");
                }
            else
            {
                juego.reinicioParcial();
                reiniciarTablero();

                jugarIA.Enabled = false;
                gbDificultad.Enabled = false;
                jugarIA.Text = "Jugar";
            }
        }


        /// <summary>
        /// Proceso que determina la navegación en la aplicación para 2 jugadores.
        /// </summary>
        public void flujoDeJuego2Jugadores()
        {
            if (!juego.fin)
                if (tbNombreJ1.Text != string.Empty && tbNombreJ2.Text != string.Empty)
                {
                    juego.jugador1.nombre = tbNombreJ1.Text;
                    juego.jugador2.nombre = tbNombreJ2.Text;
                    juego.tipo = 2;

                    acomodarJuego();
                }
                else
                {
                    MessageBox.Show("Ingrese los nombres de ambos jugadores primero.");
                }
            else
            {
                juego.reinicioParcial();
                reiniciarTablero();

                empezarJuego.Enabled = false;
                empezarJuego.Text = "Jugar";
                moverFlecha();

            }
        }

        public void flujoDeJuegoMaquinas()
        {
            reiniciarTablero();
            juego.reinicioParcial();
            btnObservarM.Enabled = false;
            jugarIA.Enabled = false;
            tbJugadorIA.Enabled = false;
            gbDificultad.Enabled = false;
            btnObservarM.Enabled = false;
            empezarJuego.Enabled = false;
            tbNombreJ1.Enabled = false;
            tbNombreJ2.Enabled = false;

            juego.jugador1.nombre = "Máquina X";
            juego.jugador2.nombre = "Máquina O";
            juego.tipo = 3;
            btnObservarM.Text = "¡Otra vez!";

            for (int i = 0; i < 9; i++)
            {
                jugadaDeIA();
                Thread.Sleep(500);

                if (juego.fin) break;
            }

            lbPuntosEmpateM.Text = Convert.ToString(juego.empates);
            lbPuntosM1.Text = Convert.ToString(juego.jugador1.puntuación);
            lbPuntosM2.Text = Convert.ToString(juego.jugador2.puntuación);



            reiniciarTablero();
            juego.reinicioParcial();
            btnObservarM.Enabled = true;
            tablero.Enabled = false;

        }

        /// <summary>
        /// Conjunto de todas las acciones comunes en los botones el tablero
        /// </summary>
        public void accionesGeneralesBotones()
        {
            if (juego.tipo == 2)
            {
                if (!juego.fin)
                    moverFlecha();
                else
                {
                    empezarJuego.Enabled = true;
                    empezarJuego.Text = "¡Revancha!";
                    tablero.Enabled = false;
                    scoreJ1.Text = juego.jugador1.puntuación.ToString();
                    scoreJ2.Text = juego.jugador2.puntuación.ToString();

                }
            }
            else if (juego.tipo == 1)
            {
                if (!juego.fin)
                {
                    tablero.Enabled = false;
                    jugadaDeIA();
                    Thread.Sleep(200);
                    if (!juego.fin)
                        tablero.Enabled = true;
                    else
                    {
                        lbPuntosJugador.Text = juego.jugador1.puntuación.ToString();
                        lbPuntosIA.Text = juego.jugador2.puntuación.ToString();
                        lbPuntosEmpate.Text = juego.empates.ToString();
                        jugarIA.Enabled = true;
                        gbDificultad.Enabled = true;
                        jugarIA.Text = "¡Revancha!";
                        tablero.Enabled = false;
                    }
                }
                else
                {
                    lbPuntosJugador.Text = juego.jugador1.puntuación.ToString();
                    lbPuntosIA.Text = juego.jugador2.puntuación.ToString();
                    lbPuntosEmpate.Text = juego.empates.ToString();
                    jugarIA.Enabled = true;
                    gbDificultad.Enabled = true;
                    jugarIA.Text = "¡Revancha!";
                    tablero.Enabled = false;

                }
            }
        }

        private void btnObservarM_Click(object sender, EventArgs e)
        {
            flujoDeJuegoMaquinas();
        }


        private void empezarJuego_Click(object sender, EventArgs e)
        {
            flujoDeJuego2Jugadores();
        }

        private void jugarIA_Click(object sender, EventArgs e)
        {
            flujoDeJuego1Jugador();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            juego.reinicioTotal();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            panel1.Left = ClientSize.Width / 2 - panel1.Width / 2;
            panel1.Top = ClientSize.Height / 2 - panel1.Height / 2;
        }


        //........................ Inicio botones del Tablero .............................
        private void btn00_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn00, 0, 0);
            accionesGeneralesBotones();
        }

        private void btn01_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn01, 0, 1);
            accionesGeneralesBotones();
        }

        private void btn02_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn02, 0, 2);
            accionesGeneralesBotones();
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn10, 1, 0);
            accionesGeneralesBotones();
        }

        private void btn11_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn11, 1, 1);
            accionesGeneralesBotones();
        }

        private void btn12_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn12, 1, 2);
            accionesGeneralesBotones();
        }

        private void btn20_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn20, 2, 0);
            accionesGeneralesBotones();
        }

        private void btn21_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn21, 2, 1);
            accionesGeneralesBotones();
        }

        private void btn22_Click(object sender, EventArgs e)
        {
            juego.ingresarJugada(ref btn22, 2, 2);
            accionesGeneralesBotones();
        }


        private void previsualizar(ref Button btn)
        {
            if (btn.Enabled)
            {
                if (juego.turno)
                    btn.Text = "X";
                else
                    btn.Text = "O";
            }
        }

        private void borrarVistaPrevia(ref Button btn)
        {
            if (btn.Enabled)
            {
                btn.Text = "";
            }
        }

        private void btn00_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn00);
        }

        private void btn00_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn00);
        }


        private void btn01_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn01);
        }


        private void btn01_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn01);
        }

        private void btn02_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn02);
        }

        private void btn02_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn02);
        }

        private void btn10_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn10);
        }

        private void btn10_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn10);
        }

        private void btn11_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn11);
        }

        private void btn11_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn11);
        }

        private void btn12_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn12);
        }

        private void btn12_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn12);
        }

        private void btn20_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn20);
        }

        private void btn20_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn20);
        }

        private void btn21_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn21);
        }

        private void btn21_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn21);
        }

        private void btn22_MouseMove(object sender, MouseEventArgs e)
        {
            previsualizar(ref btn22);
        }

        private void btn22_MouseLeave(object sender, EventArgs e)
        {
            borrarVistaPrevia(ref btn22);
        }





        //........................ Fin botones del tablero .............................


    }
}
