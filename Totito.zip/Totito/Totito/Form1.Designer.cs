﻿namespace Totito
{
    partial class Form1
    {



        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.scoreJ2 = new System.Windows.Forms.Label();
            this.scoreJ1 = new System.Windows.Forms.Label();
            this.simbolo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.flecha = new System.Windows.Forms.PictureBox();
            this.lbIndicador = new System.Windows.Forms.Label();
            this.instrucciones = new System.Windows.Forms.Label();
            this.tbNombreJ2 = new System.Windows.Forms.TextBox();
            this.tbNombreJ1 = new System.Windows.Forms.TextBox();
            this.empezarJuego = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbPuntosEmpate = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbPuntosIA = new System.Windows.Forms.Label();
            this.lbPuntosJugador = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.gbDificultad = new System.Windows.Forms.GroupBox();
            this.rbDificil = new System.Windows.Forms.RadioButton();
            this.rbIntermedio = new System.Windows.Forms.RadioButton();
            this.rbFacil = new System.Windows.Forms.RadioButton();
            this.jugarIA = new System.Windows.Forms.Button();
            this.tbJugadorIA = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnObservarM = new System.Windows.Forms.Button();
            this.lbPuntosEmpateM = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbPuntosM2 = new System.Windows.Forms.Label();
            this.lbPuntosM1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tablero = new System.Windows.Forms.GroupBox();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn02 = new System.Windows.Forms.Button();
            this.btn01 = new System.Windows.Forms.Button();
            this.btn00 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flecha)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.gbDificultad.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tablero.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI Light", 10F);
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(21, 129);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(348, 338);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.scoreJ2);
            this.tabPage1.Controls.Add(this.scoreJ1);
            this.tabPage1.Controls.Add(this.simbolo);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.flecha);
            this.tabPage1.Controls.Add(this.lbIndicador);
            this.tabPage1.Controls.Add(this.instrucciones);
            this.tabPage1.Controls.Add(this.tbNombreJ2);
            this.tabPage1.Controls.Add(this.tbNombreJ1);
            this.tabPage1.Controls.Add(this.empezarJuego);
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI Light", 10F);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(340, 308);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "2 Jugadores";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(295, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "P";
            this.label4.Visible = false;
            // 
            // scoreJ2
            // 
            this.scoreJ2.AutoSize = true;
            this.scoreJ2.Location = new System.Drawing.Point(295, 104);
            this.scoreJ2.Name = "scoreJ2";
            this.scoreJ2.Size = new System.Drawing.Size(16, 19);
            this.scoreJ2.TabIndex = 10;
            this.scoreJ2.Text = "0";
            this.scoreJ2.Visible = false;
            // 
            // scoreJ1
            // 
            this.scoreJ1.AutoSize = true;
            this.scoreJ1.Location = new System.Drawing.Point(295, 73);
            this.scoreJ1.Name = "scoreJ1";
            this.scoreJ1.Size = new System.Drawing.Size(16, 19);
            this.scoreJ1.TabIndex = 9;
            this.scoreJ1.Text = "0";
            this.scoreJ1.Visible = false;
            // 
            // simbolo
            // 
            this.simbolo.AllowDrop = true;
            this.simbolo.AutoSize = true;
            this.simbolo.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.simbolo.Location = new System.Drawing.Point(254, 206);
            this.simbolo.Name = "simbolo";
            this.simbolo.Size = new System.Drawing.Size(68, 72);
            this.simbolo.TabIndex = 8;
            this.simbolo.Text = "X";
            this.simbolo.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.simbolo.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Jugador 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Jugador 1";
            // 
            // flecha
            // 
            this.flecha.Image = ((System.Drawing.Image)(resources.GetObject("flecha.Image")));
            this.flecha.Location = new System.Drawing.Point(42, 240);
            this.flecha.Name = "flecha";
            this.flecha.Size = new System.Drawing.Size(27, 25);
            this.flecha.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.flecha.TabIndex = 5;
            this.flecha.TabStop = false;
            this.flecha.Visible = false;
            // 
            // lbIndicador
            // 
            this.lbIndicador.Font = new System.Drawing.Font("Segoe UI Light", 12F);
            this.lbIndicador.Location = new System.Drawing.Point(19, 212);
            this.lbIndicador.Name = "lbIndicador";
            this.lbIndicador.Size = new System.Drawing.Size(51, 25);
            this.lbIndicador.TabIndex = 4;
            this.lbIndicador.Text = "Turno";
            this.lbIndicador.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbIndicador.Visible = false;
            // 
            // instrucciones
            // 
            this.instrucciones.AutoSize = true;
            this.instrucciones.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instrucciones.Location = new System.Drawing.Point(3, 3);
            this.instrucciones.Name = "instrucciones";
            this.instrucciones.Size = new System.Drawing.Size(230, 17);
            this.instrucciones.TabIndex = 3;
            this.instrucciones.Text = "Ingrese el nombre de los jugadores:";
            // 
            // tbNombreJ2
            // 
            this.tbNombreJ2.Location = new System.Drawing.Point(42, 134);
            this.tbNombreJ2.Name = "tbNombreJ2";
            this.tbNombreJ2.Size = new System.Drawing.Size(252, 25);
            this.tbNombreJ2.TabIndex = 2;
            // 
            // tbNombreJ1
            // 
            this.tbNombreJ1.Location = new System.Drawing.Point(42, 70);
            this.tbNombreJ1.Name = "tbNombreJ1";
            this.tbNombreJ1.Size = new System.Drawing.Size(252, 25);
            this.tbNombreJ1.TabIndex = 1;
            // 
            // empezarJuego
            // 
            this.empezarJuego.BackColor = System.Drawing.Color.Orange;
            this.empezarJuego.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.empezarJuego.FlatAppearance.BorderSize = 0;
            this.empezarJuego.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.empezarJuego.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.empezarJuego.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.empezarJuego.Location = new System.Drawing.Point(95, 212);
            this.empezarJuego.Name = "empezarJuego";
            this.empezarJuego.Size = new System.Drawing.Size(153, 67);
            this.empezarJuego.TabIndex = 0;
            this.empezarJuego.Text = "Jugar";
            this.empezarJuego.UseVisualStyleBackColor = false;
            this.empezarJuego.Click += new System.EventHandler(this.empezarJuego_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lbPuntosEmpate);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.lbPuntosIA);
            this.tabPage2.Controls.Add(this.lbPuntosJugador);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.gbDificultad);
            this.tabPage2.Controls.Add(this.jugarIA);
            this.tabPage2.Controls.Add(this.tbJugadorIA);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(340, 308);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Jugar contra IA";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lbPuntosEmpate
            // 
            this.lbPuntosEmpate.Location = new System.Drawing.Point(194, 220);
            this.lbPuntosEmpate.Name = "lbPuntosEmpate";
            this.lbPuntosEmpate.Size = new System.Drawing.Size(116, 19);
            this.lbPuntosEmpate.TabIndex = 10;
            this.lbPuntosEmpate.Text = "0";
            this.lbPuntosEmpate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(221, 201);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Empates:";
            // 
            // lbPuntosIA
            // 
            this.lbPuntosIA.Location = new System.Drawing.Point(194, 176);
            this.lbPuntosIA.Name = "lbPuntosIA";
            this.lbPuntosIA.Size = new System.Drawing.Size(116, 19);
            this.lbPuntosIA.TabIndex = 8;
            this.lbPuntosIA.Text = "0";
            this.lbPuntosIA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPuntosJugador
            // 
            this.lbPuntosJugador.Location = new System.Drawing.Point(194, 131);
            this.lbPuntosJugador.Name = "lbPuntosJugador";
            this.lbPuntosJugador.Size = new System.Drawing.Size(116, 19);
            this.lbPuntosJugador.TabIndex = 7;
            this.lbPuntosJugador.Text = "0";
            this.lbPuntosJugador.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(212, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Puntos de IA";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(195, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Puntos de Jugador";
            // 
            // gbDificultad
            // 
            this.gbDificultad.Controls.Add(this.rbDificil);
            this.gbDificultad.Controls.Add(this.rbIntermedio);
            this.gbDificultad.Controls.Add(this.rbFacil);
            this.gbDificultad.Location = new System.Drawing.Point(31, 76);
            this.gbDificultad.Name = "gbDificultad";
            this.gbDificultad.Size = new System.Drawing.Size(155, 119);
            this.gbDificultad.TabIndex = 4;
            this.gbDificultad.TabStop = false;
            this.gbDificultad.Text = "Dificultad";
            // 
            // rbDificil
            // 
            this.rbDificil.AutoSize = true;
            this.rbDificil.Location = new System.Drawing.Point(6, 82);
            this.rbDificil.Name = "rbDificil";
            this.rbDificil.Size = new System.Drawing.Size(58, 23);
            this.rbDificil.TabIndex = 2;
            this.rbDificil.Text = "Difícil";
            this.rbDificil.UseVisualStyleBackColor = true;
            // 
            // rbIntermedio
            // 
            this.rbIntermedio.AutoSize = true;
            this.rbIntermedio.Location = new System.Drawing.Point(6, 53);
            this.rbIntermedio.Name = "rbIntermedio";
            this.rbIntermedio.Size = new System.Drawing.Size(91, 23);
            this.rbIntermedio.TabIndex = 1;
            this.rbIntermedio.Text = "Intermedio";
            this.rbIntermedio.UseVisualStyleBackColor = true;
            // 
            // rbFacil
            // 
            this.rbFacil.AutoSize = true;
            this.rbFacil.Checked = true;
            this.rbFacil.Location = new System.Drawing.Point(6, 24);
            this.rbFacil.Name = "rbFacil";
            this.rbFacil.Size = new System.Drawing.Size(53, 23);
            this.rbFacil.TabIndex = 0;
            this.rbFacil.TabStop = true;
            this.rbFacil.Text = "Fácil";
            this.rbFacil.UseVisualStyleBackColor = true;
            // 
            // jugarIA
            // 
            this.jugarIA.BackColor = System.Drawing.Color.Orange;
            this.jugarIA.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.jugarIA.FlatAppearance.BorderSize = 0;
            this.jugarIA.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.jugarIA.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.jugarIA.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.jugarIA.Location = new System.Drawing.Point(31, 210);
            this.jugarIA.Name = "jugarIA";
            this.jugarIA.Size = new System.Drawing.Size(155, 67);
            this.jugarIA.TabIndex = 3;
            this.jugarIA.Text = "Jugar";
            this.jugarIA.UseVisualStyleBackColor = false;
            this.jugarIA.Click += new System.EventHandler(this.jugarIA_Click);
            // 
            // tbJugadorIA
            // 
            this.tbJugadorIA.Location = new System.Drawing.Point(31, 39);
            this.tbJugadorIA.Name = "tbJugadorIA";
            this.tbJugadorIA.Size = new System.Drawing.Size(268, 25);
            this.tbJugadorIA.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(274, 19);
            this.label5.TabIndex = 1;
            this.label5.Text = "Jugador: (Siempre primer turno y símbolo X)";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnObservarM);
            this.tabPage3.Controls.Add(this.lbPuntosEmpateM);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.lbPuntosM2);
            this.tabPage3.Controls.Add(this.lbPuntosM1);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(340, 308);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Máquina vs Máquina";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnObservarM
            // 
            this.btnObservarM.BackColor = System.Drawing.Color.Orange;
            this.btnObservarM.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnObservarM.FlatAppearance.BorderSize = 0;
            this.btnObservarM.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnObservarM.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnObservarM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnObservarM.Location = new System.Drawing.Point(63, 159);
            this.btnObservarM.Name = "btnObservarM";
            this.btnObservarM.Size = new System.Drawing.Size(213, 101);
            this.btnObservarM.TabIndex = 17;
            this.btnObservarM.Text = "Observar";
            this.btnObservarM.UseVisualStyleBackColor = false;
            this.btnObservarM.Click += new System.EventHandler(this.btnObservarM_Click);
            // 
            // lbPuntosEmpateM
            // 
            this.lbPuntosEmpateM.Location = new System.Drawing.Point(108, 102);
            this.lbPuntosEmpateM.Name = "lbPuntosEmpateM";
            this.lbPuntosEmpateM.Size = new System.Drawing.Size(116, 19);
            this.lbPuntosEmpateM.TabIndex = 16;
            this.lbPuntosEmpateM.Text = "0";
            this.lbPuntosEmpateM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(135, 85);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 17);
            this.label11.TabIndex = 15;
            this.label11.Text = "Empates:";
            // 
            // lbPuntosM2
            // 
            this.lbPuntosM2.Location = new System.Drawing.Point(184, 54);
            this.lbPuntosM2.Name = "lbPuntosM2";
            this.lbPuntosM2.Size = new System.Drawing.Size(116, 19);
            this.lbPuntosM2.TabIndex = 14;
            this.lbPuntosM2.Text = "0";
            this.lbPuntosM2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPuntosM1
            // 
            this.lbPuntosM1.Location = new System.Drawing.Point(30, 54);
            this.lbPuntosM1.Name = "lbPuntosM1";
            this.lbPuntosM1.Size = new System.Drawing.Size(116, 19);
            this.lbPuntosM1.TabIndex = 13;
            this.lbPuntosM1.Text = "0";
            this.lbPuntosM1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(180, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(123, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "Puntos máquina O";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(31, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 17);
            this.label15.TabIndex = 11;
            this.label15.Text = "Puntos máquina X";
            // 
            // tablero
            // 
            this.tablero.Controls.Add(this.btn22);
            this.tablero.Controls.Add(this.btn21);
            this.tablero.Controls.Add(this.btn20);
            this.tablero.Controls.Add(this.btn12);
            this.tablero.Controls.Add(this.btn11);
            this.tablero.Controls.Add(this.btn10);
            this.tablero.Controls.Add(this.btn02);
            this.tablero.Controls.Add(this.btn01);
            this.tablero.Controls.Add(this.btn00);
            this.tablero.Enabled = false;
            this.tablero.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tablero.Location = new System.Drawing.Point(392, 145);
            this.tablero.Name = "tablero";
            this.tablero.Size = new System.Drawing.Size(337, 322);
            this.tablero.TabIndex = 1;
            this.tablero.TabStop = false;
            this.tablero.Text = "Tablero";
            // 
            // btn22
            // 
            this.btn22.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn22.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn22.Location = new System.Drawing.Point(217, 215);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(86, 86);
            this.btn22.TabIndex = 8;
            this.btn22.TabStop = false;
            this.btn22.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn22.UseVisualStyleBackColor = false;
            this.btn22.Click += new System.EventHandler(this.btn22_Click);
            this.btn22.MouseLeave += new System.EventHandler(this.btn22_MouseLeave);
            this.btn22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn22_MouseMove);
            // 
            // btn21
            // 
            this.btn21.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn21.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn21.Location = new System.Drawing.Point(125, 215);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(86, 86);
            this.btn21.TabIndex = 7;
            this.btn21.TabStop = false;
            this.btn21.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn21.UseVisualStyleBackColor = false;
            this.btn21.Click += new System.EventHandler(this.btn21_Click);
            this.btn21.MouseLeave += new System.EventHandler(this.btn21_MouseLeave);
            this.btn21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn21_MouseMove);
            // 
            // btn20
            // 
            this.btn20.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn20.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn20.Location = new System.Drawing.Point(33, 215);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(86, 86);
            this.btn20.TabIndex = 6;
            this.btn20.TabStop = false;
            this.btn20.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn20.UseVisualStyleBackColor = false;
            this.btn20.Click += new System.EventHandler(this.btn20_Click);
            this.btn20.MouseLeave += new System.EventHandler(this.btn20_MouseLeave);
            this.btn20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn20_MouseMove);
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn12.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn12.Location = new System.Drawing.Point(217, 123);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(86, 86);
            this.btn12.TabIndex = 5;
            this.btn12.TabStop = false;
            this.btn12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn12.UseVisualStyleBackColor = false;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            this.btn12.MouseLeave += new System.EventHandler(this.btn12_MouseLeave);
            this.btn12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn12_MouseMove);
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn11.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn11.Location = new System.Drawing.Point(125, 123);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(86, 86);
            this.btn11.TabIndex = 4;
            this.btn11.TabStop = false;
            this.btn11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            this.btn11.MouseLeave += new System.EventHandler(this.btn11_MouseLeave);
            this.btn11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn11_MouseMove);
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn10.Location = new System.Drawing.Point(33, 123);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(86, 86);
            this.btn10.TabIndex = 3;
            this.btn10.TabStop = false;
            this.btn10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn10.UseVisualStyleBackColor = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            this.btn10.MouseLeave += new System.EventHandler(this.btn10_MouseLeave);
            this.btn10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn10_MouseMove);
            // 
            // btn02
            // 
            this.btn02.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn02.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn02.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn02.Location = new System.Drawing.Point(217, 31);
            this.btn02.Name = "btn02";
            this.btn02.Size = new System.Drawing.Size(86, 86);
            this.btn02.TabIndex = 2;
            this.btn02.TabStop = false;
            this.btn02.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn02.UseVisualStyleBackColor = false;
            this.btn02.Click += new System.EventHandler(this.btn02_Click);
            this.btn02.MouseLeave += new System.EventHandler(this.btn02_MouseLeave);
            this.btn02.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn02_MouseMove);
            // 
            // btn01
            // 
            this.btn01.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn01.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn01.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn01.Location = new System.Drawing.Point(125, 31);
            this.btn01.Name = "btn01";
            this.btn01.Size = new System.Drawing.Size(86, 86);
            this.btn01.TabIndex = 1;
            this.btn01.TabStop = false;
            this.btn01.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn01.UseVisualStyleBackColor = false;
            this.btn01.Click += new System.EventHandler(this.btn01_Click);
            this.btn01.MouseLeave += new System.EventHandler(this.btn01_MouseLeave);
            this.btn01.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn01_MouseMove);
            // 
            // btn00
            // 
            this.btn00.AllowDrop = true;
            this.btn00.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn00.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn00.Font = new System.Drawing.Font("Segoe UI Black", 40.25F, System.Drawing.FontStyle.Bold);
            this.btn00.Location = new System.Drawing.Point(33, 31);
            this.btn00.Name = "btn00";
            this.btn00.Size = new System.Drawing.Size(86, 86);
            this.btn00.TabIndex = 0;
            this.btn00.TabStop = false;
            this.btn00.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn00.UseVisualStyleBackColor = false;
            this.btn00.Click += new System.EventHandler(this.btn00_Click);
            this.btn00.MouseLeave += new System.EventHandler(this.btn00_MouseLeave);
            this.btn00.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btn00_MouseMove);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 40.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.Location = new System.Drawing.Point(452, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 74);
            this.label1.TabIndex = 2;
            this.label1.Text = "¡Totito!";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(21, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 30);
            this.button1.TabIndex = 9;
            this.button1.Text = "Nuevo Juego";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(193, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Para cambiar de turno o modo de juego:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tablero);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(72, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(757, 484);
            this.panel1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(901, 571);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI Light", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Totito - Andrés Sanabria 17030008";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flecha)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.gbDificultad.ResumeLayout(false);
            this.gbDificultad.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tablero.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private  System.Windows.Forms.TabControl tabControl1;
        private  System.Windows.Forms.TabPage tabPage1;
        private  System.Windows.Forms.TabPage tabPage2;
        private  System.Windows.Forms.GroupBox tablero;
        private  System.Windows.Forms.Button btn00;
        private  System.Windows.Forms.Button btn22;
        private  System.Windows.Forms.Button btn21;
        private  System.Windows.Forms.Button btn20;
        private  System.Windows.Forms.Button btn12;
        private  System.Windows.Forms.Button btn11;
        private  System.Windows.Forms.Button btn10;
        private  System.Windows.Forms.Button btn02;
        private  System.Windows.Forms.Button btn01;
        private  System.Windows.Forms.Button empezarJuego;
        private  System.Windows.Forms.TextBox tbNombreJ2;
        private  System.Windows.Forms.TextBox tbNombreJ1;
        private  System.Windows.Forms.Label label1;
        private  System.Windows.Forms.Label instrucciones;
        private  System.Windows.Forms.Label label3;
        private  System.Windows.Forms.Label label2;
        private  System.Windows.Forms.PictureBox flecha;
        private  System.Windows.Forms.Label lbIndicador;
        private  System.Windows.Forms.Label simbolo;
        private  System.Windows.Forms.Label scoreJ2;
        private  System.Windows.Forms.Label scoreJ1;
        private  System.Windows.Forms.Label label4;
        private  System.Windows.Forms.Button button1;
        private  System.Windows.Forms.TextBox tbJugadorIA;
        private  System.Windows.Forms.Label label5;
        private  System.Windows.Forms.Button jugarIA;
        private  System.Windows.Forms.GroupBox gbDificultad;
        private  System.Windows.Forms.RadioButton rbDificil;
        private  System.Windows.Forms.RadioButton rbIntermedio;
        private  System.Windows.Forms.RadioButton rbFacil;
        private  System.Windows.Forms.Label lbPuntosIA;
        private  System.Windows.Forms.Label lbPuntosJugador;
        private  System.Windows.Forms.Label label7;
        private  System.Windows.Forms.Label label6;
        private  System.Windows.Forms.Label label8;
        private  System.Windows.Forms.Label lbPuntosEmpate;
        private  System.Windows.Forms.Label label9;
        private  System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnObservarM;
        private System.Windows.Forms.Label lbPuntosEmpateM;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbPuntosM2;
        private System.Windows.Forms.Label lbPuntosM1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}

