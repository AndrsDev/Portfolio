﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Totito
{ 
    class Game
    {
        private int[,] posiciones;
        public bool turno, fin;
        public Player jugador1, jugador2;
        public int tipo, empates;


        /// <summary>
        /// Constructor de la clase que prepara las condiciones base del juego.
        /// </summary>
        public Game()
        {
            posiciones = new int[3, 3] { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };
            turno = true;
            fin = false;
            empates = 0;

            jugador1 = new Player("X");
            jugador2 = new Player("O");
        }

        /// <summary>
        /// Reinicia la aplicación a su inicio
        /// </summary>
        public void reinicioTotal()
        {
            Application.Restart();
        }

        /// <summary>
        /// Reinicia las condiciones de juego para jugar una revancha
        /// </summary>
        public void reinicioParcial()
        {
            posiciones = new int[3, 3] { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };
            turno = true;
            fin = false;
        } 

        /// <summary>
        /// Determina que tan cerca está de ganar el jugador 1 y el jugador 2, si formaron una linea de 3 o si 
        /// empataron.
        /// </summary>
        /// <param name="contJ1Inicial">Conteo de posibilidad del jugador 1</param>
        /// <param name="contJ2Inicial">Conteo de posibilidad del jugador 2</param>
        /// <param name="vacias"></param>
        private void obtenerPuntosDeGanancia(ref int contJ1Inicial, ref int contJ2Inicial, ref int vacias)
        {
            int contJ1 = 0, contJ2 = 0;

            //verificación de filas y casillas vacías
            for (int i = 0; i < 3; i++)
            {

                contJ1 = 0;
                contJ2 = 0;


                for (int i2 = 0; i2 < 3; i2++)
                {

                    if (posiciones[i, i2] == 1)
                        contJ1++; 
                    else if (posiciones[i, i2] == 2)
                        contJ2++; 
                    else vacias++;
                }

                if (contJ2 > 0 & contJ1 > 0)
                {
                    contJ1 = 0;
                    contJ2 = 0;
                }


                if (contJ1Inicial < contJ1) contJ1Inicial = contJ1;
                if (contJ2Inicial < contJ2) contJ2Inicial = contJ2;
            }

            //Verificación de columnas
            for (int i = 0; i < 3; i++)
            {

                contJ1 = 0;
                contJ2 = 0;

                for (int i2 = 0; i2 < 3; i2++)
                {
                    if (posiciones[i2, i] == 1)
                        contJ1++;
                    else if (posiciones[i2, i] == 2)
                        contJ2++; 
                }


                if (contJ2 > 0 & contJ1 > 0)
                {
                    contJ1 = 0;
                    contJ2 = 0;
                }

                if (contJ1Inicial < contJ1) contJ1Inicial = contJ1;
                if (contJ2Inicial < contJ2) contJ2Inicial = contJ2;
            }

            //Verificación de diagonal "\"
            contJ1 = 0; contJ2 = 0;
            for (int i = 0; i < 3; i++)
            {
                if (posiciones[i, i] == 1)
                    contJ1++;
                else if (posiciones[i, i] == 2)
                    contJ2++; 
            }

            if (contJ2 > 0 & contJ1 > 0)
            {
                contJ1 = 0;
                contJ2 = 0;
            }

            if (contJ1Inicial < contJ1) contJ1Inicial = contJ1;
            if (contJ2Inicial < contJ2) contJ2Inicial = contJ2;

            //Verificación de diagonal "/"
            contJ1 = 0; contJ2 = 0;
            for (int i = 0; i < 3; i++)
            {
                if (posiciones[i, 2 - i] == 1)
                    contJ1++;
                else if (posiciones[i, 2 - i] == 2)
                    contJ2++;
            }

            if (contJ2 > 0 & contJ1 > 0)
            {
                contJ1 = 0;
                contJ2 = 0;
            }

            if (contJ1Inicial < contJ1) contJ1Inicial = contJ1;
            if (contJ2Inicial < contJ2) contJ2Inicial = contJ2;

        }

        /// <summary>
        /// Según el proceso de obtenerPuntosDeGanancia() muestra un mensaje que muestra el resultado del juego.  
        /// </summary>
        /// <returns></returns>
        private void verificarGanador()
        {
            int vacias = 0, lineaJ1 = 0,lineaJ2=0;


            obtenerPuntosDeGanancia(ref lineaJ1, ref lineaJ2, ref vacias);


            if (lineaJ1 == 3)
            {
                MessageBox.Show("¡Ganó " + jugador1.nombre + "!");
                jugador1.puntuación++;
                this.fin = true;
            }
            else if (lineaJ2 == 3)
            {
                MessageBox.Show("¡Ganó " + jugador2.nombre + "!");
                jugador2.puntuación++;
                this.fin = true;
            }
            else if (vacias == 0)
            {
                MessageBox.Show("¡" + jugador1.nombre + " y " + jugador2.nombre + " empataron!");
                this.fin = true;
                this.empates++;
            }



        }

        /// <summary>
        /// Ingresa la cordenada en la matriz y llama al procedimiento verificarGanador() para evaluar la jugada.
        /// </summary>
        /// <param name="btn">Botón a actualizar en la interfaz</param>
        /// <param name="px">coordenada en x</param>
        /// <param name="py">coordenada en y</param>
        public void ingresarJugada(ref Button btn,int px,int py)
        {
            if (turno)
            {
                btn.Text = jugador1.signo;
                posiciones[px, py] = 1;
            }
            else
            {
                btn.Text = jugador2.signo;            
                posiciones[px, py] = 2;
            }

            turno = !turno;
            btn.Enabled = false;
            verificarGanador();


        }

        /// <summary>
        /// Funcion para obtener una coordenada random
        /// </summary>
        /// <returns>Coordenada en el tablero</returns>
        public string inteligenciaNivel1()
        {
            Random rnd = new Random();
            int px = 0, py = 0;
            switch (rnd.Next(4))
            {
                case 0:
                    for (int i = 0; i < 9; i++)
                        if (posiciones[i / 3, i % 3] == 0)
                        {
                            px = i / 3;
                            py = i % 3;
                        }
                    break;
                case 1:
                    for (int i = 0; i < 9; i++)
                        if (posiciones[i % 3, i / 3] == 0)
                        {
                            px = i % 3;
                            py = i / 3;
                        }
                    break;
                case 2:
                    for (int i = 8; i >= 0; i--)
                        if (posiciones[i % 3, i / 3] == 0)
                        {
                            px = i % 3;
                            py = i / 3;
                        }
                    break;
                case 3:
                    for (int i = 8; i >= 0; i--)
                        if (posiciones[i / 3, i % 3] == 0)
                        {
                            px = i / 3;
                            py = i % 3;
                        }
                    break;
            }
            return Convert.ToString(px) + Convert.ToString(py);
        }

        /// <summary>
        /// Funcion para obtener una coordenada de acuerdo a lógica
        /// </summary>
        /// <returns>Coordenada en el tablero</returns>
        public string inteligenciaNivel2()
        {
            Random rnd = new Random();
            int px = 0, py = 0, numJugada=0;
            int pxFinal = 0, pyFinal = 0;

            int[,] valorDeJugada = new int[3, 3] { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };

            for (int i = 0; i < 9; i++)
                if (posiciones[i / 3, i % 3] != 0)
                    numJugada++;


            if (numJugada == 0)
                return Convert.ToString(rnd.Next(3)) + Convert.ToString(rnd.Next(3));
            else {
                int aleatorio = rnd.Next(4);
                for (int i = 0; i < 9; i++)
                {

                    int jugador = 0, IA = 0, vacias = 0;

                    switch (aleatorio)
                    {
                        case 0:
                            px = i / 3;
                            py = i % 3;
                            break;
                        case 1:
                            px = i % 3;
                            py = i / 3;
                            break;
                        case 2:
                            px = i / 3;
                            py = 2 - (i % 3);
                            break;
                        default:
                            px = 2 - (i % 3);
                            py = i / 3;
                            break;
                    }


                    if (posiciones[px, py] == 0)
                    {

                        posiciones[px, py] = 2;
                        if (!turno)
                            obtenerPuntosDeGanancia(ref jugador, ref IA, ref vacias);
                        else
                            obtenerPuntosDeGanancia(ref IA, ref jugador, ref vacias);

                        posiciones[px, py] = 0;



                        if (IA == 3)
                            valorDeJugada[px, py] = 8;
                        else if (jugador == 2)
                            valorDeJugada[px, py] = 0;
                        else if (jugador == 0 & IA == 2)
                            valorDeJugada[px, py] = 7;
                        else if (jugador == 0 & IA == 1)
                            valorDeJugada[px, py] = 6;
                        else if (jugador == 0 & IA == 0)
                            valorDeJugada[px, py] = 5;
                        else if (jugador == 1 & IA == 2)
                            valorDeJugada[px, py] = 4;
                        else if (jugador == 1 & IA == 1)
                            valorDeJugada[px, py] = 3;
                        else if (jugador == 1 & IA == 0)
                            valorDeJugada[px, py] = 2;
                        else
                            valorDeJugada[px, py] = 1;



                        if (valorDeJugada[pxFinal, pyFinal] < valorDeJugada[px, py])
                        {
                            pxFinal = px;
                            pyFinal = py;
                        }

                    }
                    else
                        valorDeJugada[px, py] = -1;
                }
                return Convert.ToString(pxFinal) + Convert.ToString(pyFinal);
            }


        }

        /// <summary>
        /// Funcion para obtener una coordenada de acuerdo a lógica y patrones establecidos
        /// </summary>
        /// <returns>Coordenada en el tablero</returns>
        public string inteligenciaNivel3()
        {
            /* Working on minimax algorithm
             
                int[,] state = posiciones;
                minimax(state);
                void minimax(int[,] st)
                {
              

                }
            
            */

            int px = 0, py = 0, numJugada = 0;
            string pos = "00";
            Random rnd = new Random();

            int[,] valorDeJugada = new int[3, 3] { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };

            for (int i = 0; i < 9; i++)
                if (posiciones[i / 3, i % 3] != 0)
                {
                    numJugada++; px = i / 3; py = i % 3;
                    pos = Convert.ToString(px) + Convert.ToString(py);
                }


            if (numJugada == 1)
            {
                if (pos == "11")
                {
                    switch (rnd.Next(4))
                    {
                        case 0: return "00";
                        case 1: return "02";
                        case 2: return "20";
                        default: return "22";
                    }
                }
                else
                    return "11";
            }
            else if (numJugada == 3 && ((posiciones[0, 0] == 1 && posiciones[2, 2] == 1 && posiciones[1, 1] == 2) || (posiciones[0, 2] == 1 && posiciones[2, 0] == 1 && posiciones[1, 1] == 2)))
            {
                switch (rnd.Next(4))
                {
                    case 0: return "01";
                    case 1: return "10";
                    case 2: return "12";
                    default: return "21";
                }
            }
            else if (numJugada == 3 && (posiciones[2, 0] == 1 && posiciones[1, 2] == 1 && posiciones[1, 1] == 2))
            {
                return "22";
            }
            else if (numJugada == 3 && (posiciones[0, 0] == 1 && posiciones[2, 1] == 1 && posiciones[1, 1] == 2))
            {
                return "20";
            }
            else if (numJugada == 3 && (posiciones[0, 2] == 1 && posiciones[1, 0] == 1 && posiciones[1, 1] == 2))
            {
                return "00";
            }
            else if (numJugada == 3 && (posiciones[0, 1] == 1 && posiciones[2, 2] == 1 && posiciones[1, 1] == 2))
            {
                return "02";
            }
            else if (numJugada == 3 && (posiciones[1, 0] == 1 && posiciones[2, 2] == 1 && posiciones[1, 1] == 2))
            {
                return "20";
            }
            else if (numJugada == 3 && (posiciones[0, 1] == 1 && posiciones[2, 0] == 1 && posiciones[1, 1] == 2))
            {
                return "00";
            }
            else if (numJugada == 3 && (posiciones[0, 0] == 1 && posiciones[1, 2] == 1 && posiciones[1, 1] == 2))
            {
                return "02";
            }
            else if (numJugada == 3 && (posiciones[0, 2] == 1 && posiciones[2, 1] == 1 && posiciones[1, 1] == 2))
            {
                return "22";
            }
            else if (numJugada == 3 && (posiciones[0, 0] == 1 && posiciones[1, 1] == 1 && posiciones[2, 2] == 2))
            {
                if (rnd.Next(2) == 0)
                    return "02";
                else
                    return "20";
            }
            else if (numJugada == 3 && (posiciones[0, 2] == 1 && posiciones[1, 1] == 1 && posiciones[2, 0] == 2))
            {
                if (rnd.Next(2) == 0)
                    return "00";
                else
                    return "22";
            }
            else if (numJugada == 3 && (posiciones[2, 2] == 1 && posiciones[1, 1] == 1 && posiciones[0, 0] == 2))
            {
                if (rnd.Next(2) == 0)
                    return "02";
                else
                    return "20";
            }
            else if (numJugada == 3 && (posiciones[2, 0] == 1 && posiciones[1, 1] == 1 && posiciones[0, 2] == 2))
            {
                if (rnd.Next(2) == 0)
                    return "00";
                else
                    return "22";
            }
            else
            {
                return inteligenciaNivel2();
            }
        }

       

    }
}
