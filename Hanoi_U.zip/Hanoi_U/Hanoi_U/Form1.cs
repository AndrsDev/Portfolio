﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;



namespace Hanoi_U
{

    public partial class Form1 : Form
    {
        PictureBox[] disco = new PictureBox[10];
        Stacks base1;
        Stacks base2;
        Stacks base3;
        bool creado;
        int t;

        public Form1()
        {
            InitializeComponent();
        }

        public class Stacks
        {
            public int sp;
            public int pos;
            int[] st = new int[10];

            public Stacks(int p)
            {
                sp = 0;
                pos = p;
            }

            public void push(int n)
            {
                st[sp] = n;
                sp++;
            }

            public int pop()
            {
                if (sp > 0)
                    sp--;
                return st[sp];
            }
        }

        public void recH(int disc, string a, string b, string c)
        {
            if (disc == 1)
            {
                richTextBox1.Text+= "- Pasar de la base "+ a +" a la "+ c +"\n";
            }
            else
            {
                recH(disc - 1, a, c, b);
                recH(1, a, b, c);
                recH(disc - 1, b, a, c);
            }
        }

        public void recG(int disc, Stacks a, Stacks b, Stacks c)
        {
            if (disc == 1)
            {
                int n = a.pop();

                while(disco[n].Top > 200) // Movimiento hacia arriba
                {
                    disco[n].Top--;
                    //Thread.SpinWait(50000);
                }

                if (a.pos < c.pos) //Movimiento lateral
                    while (disco[n].Left + disco[n].Width / 2 < c.pos)
                    {
                        disco[n].Left++;
                        //Thread.SpinWait(80000);
                    }
                else
                    while (disco[n].Left + disco[n].Width / 2 > c.pos)
                    {
                        disco[n].Left--;
                        //Thread.SpinWait(80000);
                    }

                while (disco[n].Top <textBox1.Top - 21 * (c.sp+1)) //bajar disco
                {
                    disco[n].Top++;
                    //Thread.SpinWait(80000);
                }

                c.push(n);

            }
            else
            {
                recG(disc - 1, a, c, b);
                recG(1, a, b, c);
                recG(disc - 1, b, a, c);
            }
        }

       
        private void crear()
        {
            void instanciar()
            {
                int cantidad = Convert.ToInt32(comboBox1.Text) - 1;
                Random rnd = new Random();
                for (int i = 0; i <= cantidad; i++)
                {
                    disco[i] = new PictureBox();

                    disco[i].Size = new System.Drawing.Size(20 * (cantidad + 1) - i * 18, 20);
                    disco[i].Left = textBox1.Left + textBox1.Width / 2 - disco[i].Width / 2;
                    disco[i].Top = textBox1.Top - disco[i].Height - 1 - i * 21;
                    disco[i].BackColor = Color.FromArgb(rnd.Next(225), rnd.Next(225), rnd.Next(225));

                    disco[i].BringToFront();
                    Controls.Add(this.disco[i]); //Siempre colocarlo al final

                    base1.push(i);
                }
                creado = true;
            }
            void destruir()
            {

                for (int i = 0; i <= t; i++)
                {
                    disco[i].Dispose();
                }
                creado = false;
            }

            if (!creado) {
                instanciar();
            }
            else
            {
                destruir();
                instanciar();
            }          
        }

        private void button1_Click(object sender, EventArgs e)
        {

            
            comboBox1.Enabled = false;
            button1.Enabled = false;
            richTextBox1.Text = "";
            

            TimeSpan stop;
            TimeSpan start = new TimeSpan(DateTime.Now.Ticks);
            recH(Convert.ToInt32(comboBox1.Text),"A","B","C");
            stop = new TimeSpan(DateTime.Now.Ticks);

            int segundos = Convert.ToInt32(stop.Subtract(start).TotalSeconds);
            int miliseg = Convert.ToInt32(stop.Subtract(start).TotalMilliseconds % 1000);

           
            label1.Text = Convert.ToString(richTextBox1.Lines.Length - 1);
            label2.Text = "Tiempo de proceso: " + Convert.ToString(segundos) + "seg "+ Convert.ToString(miliseg)+ "ms ";
            
            comboBox1.Enabled = true;
            button2.Visible = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            button1.Enabled = false;
            comboBox1.Enabled = false;

            recG(Convert.ToInt32(comboBox1.Text), base1, base2, base3);

            MessageBox.Show("¡Terminado!");
            comboBox1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            creado = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Visible = false;

            base1 = new Stacks(textBox1.Left + textBox1.Width / 2);
            base2 = new Stacks(textBox2.Left + textBox1.Width / 2);
            base3 = new Stacks(textBox3.Left + textBox1.Width / 2);


            crear();
            t = Convert.ToInt32(comboBox1.Text) - 1;
        }
    }
}
