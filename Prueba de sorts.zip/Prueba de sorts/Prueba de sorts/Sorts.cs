﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_de_sorts
{
    static class Sorts
    {
        public static void bublesort(int[] v)
        {
            int t, pos, n = v.Length - 1;

            while (n > 0)
            {
                pos = 0;
                for (int i = 1; i <= n; i++)
                    if (v[pos] < v[i])
                        pos = i;

                t = v[pos];
                v[pos] = v[n];
                v[n] = t;

                n--;
            }
        }

        public static void quicksort(int[] v)
        {
            sort(0, v.Length - 1);

            void sort(int p, int n)
            {
                int t, pos;
                if (p < n)
                {
                    pos = p;
                    for (int i = p; i <= n; i++)
                        if (v[i] < v[n])
                        {
                            t = v[i];
                            v[i] = v[pos];
                            v[pos] = t;

                            pos++;
                        }

                    t = v[n];
                    v[n] = v[pos];
                    v[pos] = t;

                    sort(p, pos - 1);
                    sort(pos + 1, n);

                }
            }
        }


        public static void unSort(ref int[] v)
        {
            int[] v2 = new int[v.Length];
            int p, n = v.Length - 1;
            Random rnd = new Random();

            while (n >= 0)
            {
                p = rnd.Next(n);

                v2[n] = v[p];
                v[p] = v[n];

                n--;
            }
            v = v2;
        }
    }
}
