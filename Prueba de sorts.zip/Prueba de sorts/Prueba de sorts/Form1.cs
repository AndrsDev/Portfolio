﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prueba_de_sorts
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static int leng = 5;
        int[] vec = new int[leng];
        Random rnd = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for(int i = 0; i < leng; i++)
            {
                vec[i] = rnd.Next(10);
                listBox1.Items.Add(vec[i]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sorts.bublesort(vec);
            //Sorts.quicksort(vec);
            listBox1.Items.Clear();
            for (int i = 0; i < leng; i++)
                listBox1.Items.Add(vec[i]);          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sorts.unSort(ref vec);
            listBox1.Items.Clear();
            for (int i = 0; i < leng; i++)
                listBox1.Items.Add(vec[i]);


        }
    }
}
